# Bubble Sort

target_list = [54, 26, 93, 17, 77, 31, 44, 55, 20]

def bubble_sort(lst):
	# Write your code below.
	
	print(lst)

bubble_sort(target_list)