__author__ = 'kwangyoun.jung'

def author():
	return __author__