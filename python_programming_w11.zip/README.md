# 국민대 경영대학원 빅데이터 경영 MBA

## Python Programming for Data Analysis

---

- 이곳은 국민대 경영대학원 빅데이터 경영 MBA 2016년 1학기 Python 프로그래밍 강의 자료를 열람할 수 있는 곳입니다.
- MIT License이며 누구나 이 Repository에 있는 자료를 이용할 수 있으나 저작권은 꼭 표기해주시기 바랍니다.
- 문의 사항은 Repository Owner에게 연락주시기 바랍니다.
